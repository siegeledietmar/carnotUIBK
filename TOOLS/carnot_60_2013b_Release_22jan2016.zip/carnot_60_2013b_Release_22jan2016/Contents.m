% CARNOT TOOLBOX
% Version 6.0  12-Dec-2014
% ***********************************************************************
% The CARNOT Toolbox (Conventional and Regenerative Energy System 
% Optimization Toolbox)is designed for optimization of Energy 
% Systems in particular house heating systems.
% ***********************************************************************
% General functions:
%   carnot                - opens the CARNOT fundamental Library Carnot
%   carsys                - opens the CARNOT System Library Carsys
%   manual                - opens the CARNOT Online Help (HTML-Format) 
%                   in your default web browser in the frame version
%   man                   - opens the CARNOT Online help (HTML-Format) at a 
%                   specified  topic in the full page version
%   examples              - opens the CARNOT Demo Window
%
%
% Files:
%   init_carnot           - init_carnot() adds the paths needed for carnot to run to your MATLAB path
%   init_carnot_savepath  - init_carnot_savepath() adds the paths needed for CARNOT to your MATLAB
%   density               - calculates the density [kg/m^3]
%   heat_capacity         - calculates the heat capacity [J/(kg*K)]
%   thermal_conductivity  - calculates the heat conductivity [W/(m*K)]
%   kinematic_viscosity   - calculates the viscosity [m^2/s]
%   enthalpy              - calculates the enthalpy [J/kg] 
%   entropy               - calculates the entropy [J/kg*K] 
%   specific_volume       - calculates the specific_volume [m^3/kg]
%   evaporation_enthalpy  - calculates the evaporation enthalpy [J/kg]
%   vapourpressure        - calculates the vapourpressure [Pa]
%   saturationtemperature - calculates the saturation temperature [�C]
%   fluidprop             - interface for property functions from the Carlib Library
%   grashof               - calculates the grashof number
%   prandtl               - calculates the Prandtl number
%   colpdrop              - calculates the pressure-drop in a collector 
%                          per collector surface [Pa/m^2]
%   checkhgt              - checks the height balance of closed hydraulic cycles
%   date2sec              - transforms a date to seconds of year
%   sec2date              - calculates the date from the corresponding number of seconds since 1st January
%   x2rel_hum             - calculates the relative humidity 
%   rel_hum2x             - calculates the absolute humidity 
%   taualfa               - calculates the transmittance - absorbance product for collector covers
%   compile               - compiles all .c files found in the directory specified as a parameter
%   hp_param              - function to determine parameters of a heat pump
%   annualcosts           - function to calculate the the annual costs of the system
%   write_try             - transfer the obsolete FORTRAN format of typical meteorological 
%                          years to a MATLAB readable form (helpful for data from Deutscher-
%                          Wetter-Dienst)

% ***********************************************************************
% This file is part of the CARNOT Blockset.
% 
% Copyright (c) 1998-2015, Solar-Institute Juelich of the FH Aachen.
% Additional Copyright for this file see list auf authors.
% All rights reserved.
% 
% Redistribution and use in source and binary forms, with or without 
% modification, are permitted provided that the following conditions are 
% met:
% 
% 1. Redistributions of source code must retain the above copyright notice, 
%    this list of conditions and the following disclaimer.
% 
% 2. Redistributions in binary form must reproduce the above copyright 
%    notice, this list of conditions and the following disclaimer in the 
%    documentation and/or other materials provided with the distribution.
% 
% 3. Neither the name of the copyright holder nor the names of its 
%    contributors may be used to endorse or promote products derived from 
%    this software without specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE 
% LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
% CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
% SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
% INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
% ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
% THE POSSIBILITY OF SUCH DAMAGE.
